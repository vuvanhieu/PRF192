#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
//===================================
int main()
  { char str[200]; 
    //system("CLS");
    printf("Enter the string : ");
    fflush(stdin);
    gets(str);
    // scanf("%[^\n]",str);
    printf("The string entered is:  %s\n", str);
    return 0;
  }
