#include <stdio.h>
#include <stdlib.h>
void input( int x)
 { x = x +10;
 }
int main()
 { system("cls");
   int y = 15;
   printf(" y = %d \n ", y);
   input(y);
   printf(" y = %d \n ", y);
   system("pause");
   return(0);
 }
 
          
