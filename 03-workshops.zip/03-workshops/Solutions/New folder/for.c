#include <stdio.h>
#include <math.h>

int main (){
	int a;
	
	a = 4;
	printf("a = %d\n", a--);
	printf("a = %d\n", a);
	printf("\n");
	
	a = 4;
	printf("a = %d\n", --a);
	printf("a = %d\n", a);
	printf("\n");
	
	for (a = 4; a >= 0; --a){
		printf("a = %d\n", a-1);
	}
	
	system("pause");
}
