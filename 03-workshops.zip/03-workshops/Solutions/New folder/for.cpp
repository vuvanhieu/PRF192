#include <stdio.h>
#include <math.h>

int main (){
	int a;
	for (a = 4; a >= 0; --a){
	printf("a = %d\n", a);
	}
	
	
	system("pause");
}
