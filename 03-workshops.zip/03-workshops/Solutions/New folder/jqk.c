#include <stdio.h>
#include <math.h>

int main (){
	char card;
	printf("card = ");
	scanf("%c", &card);
	
	if (card == 'A'){
		printf("card = 1\n");
	}
	else if (card == '2'){
		printf("card = 2\n");
	}
	else if (card == '3'){
		printf("card = 3\n");
	}
	else if (card == '4'){
		printf("card = 4\n");
	}
	else if (card == '5'){
		printf("card = 5\n");
	}
	else if (card == '6'){
		printf("card = 6\n");
	}
	else if (card == '7'){
		printf("card = 7\n");
	}
	else if (card == '8'){
		printf("card = 8\n");
	}
	else if (card == '9'){
		printf("card = 9\n");
	}
	else if (card == '0'){
		printf("card = 10\n");
	}
	else if (card == 'J'){
		printf("card = 11\n");
	}
	else if (card == 'Q'){
		printf("card = 11\n");
	}
	else if (card == 'K'){
		printf("card = 11\n");
	}
	else {
		printf("card value = %x\n", card);
		printf("invalid card\n");
	}
	
	system("pause");
}
