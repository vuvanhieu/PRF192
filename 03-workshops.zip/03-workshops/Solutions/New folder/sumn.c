#include <stdio.h>
#include <math.h>

int main (){
	int n;
	printf("n = ");
	scanf("%d", &n);
	
	int i = 1;
	int sum = 0;
	for (i=1; i<=n; i++){
		sum = sum + i;
	}
	printf("sum = %d\n", sum);
	
	i = 1;
	sum = 0;
	while (i<=n){
		sum = sum + i;
		i++;
	}
	printf("sum = %d\n", sum);
	
	i = 0;
	sum = 0;
	do{
		sum = sum + i;
		i++;
	} while (i<=n);
	printf("sum = %d\n", sum);
	
	system("pause");
}
