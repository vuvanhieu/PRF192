#include <stdio.h>
#include <stdlib.h>

int main () {
	printf ("Enter double numbers (a,b) = ");
	int a, b;
	scanf("%d%d", &a, &b);
	printf ("%d, %d\n", a, b);
	if ((a<10) || (b>100)){
		printf ("Invalid input\n");
	}
	else {
		int M = b;
		int N = a;
		int a = rand();
		a = rand();
		int output = M + a / (RAND_MAX / (N - M + 1) + 1);
		printf ("a = %d, output = %d\n", a, output);	
	}
	return;
}
