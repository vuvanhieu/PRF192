#include <stdio.h>

int main () {
	printf ("Enter:");
	char c;
	c = getchar();
	printf ("c = %c\n", c);
	return;
}
