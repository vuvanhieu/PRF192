#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void getstr(char s[], int max) {
	int i, c;
	i = 0;
	while((c = getchar()) != '\n' && c != EOF)
		if (i<max)
			s[i++]=(char) c;
	s[i] = '\0';
}


int main (){
	char s[20];
	int max = 19;
	printf("Enter string:");
	getstr(s, max);
	printf("Input string is: %s\n", s);
	
	printf("String len = %d\n", strlen(s));
	char s1[3]="ab";
	char s2[3]="de";
	strcpy(s, s2);
	printf("Strcpy = %s\n", s); //has def     h at the end
	printf("Compare s1, s2 = %d\n", strcmp(s1,s2));
	printf("Strcat = %s\n", strcat(s1, s2));
	return 0;
}
