#include <stdio.h>
#include <math.h>

int f1 (int a, int n);
float f2 (int n);
void f3 (int input);

int a;
int n;

int main (){
	int input;
	printf ("a = ");
	scanf("%d", &a);
	
	printf ("n = ");
	scanf("%d", &n);
	
	printf("select input 0/1: ");
	scanf("%d", &input);
	f3 (input);
}

int f1 (int a, int n){
	return pow (a,n);
}

float f2 (int n){
	int sum = 0;
	int ai;
	int i;
	for (i = 1; i<=n; i++)
	{
		printf ("ai = ");
		scanf("%d", &ai);
		sum += ai;
	}
	if (n == 0)
	{
		return 0;
	}
	else
	{
		return ((float) sum / n);
	}
}

void f3 (int input){
	if (input == 0)
	{
		printf ("a = %d, n = %d\n", a, n);
		printf("f1 = %d\n", f1(a,n));
	}
	else
	{
		printf ("n = %d\n", n);
		printf("f2 = %f\n", f2(n));
	}
}
