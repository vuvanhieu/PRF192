#include <stdio.h>

int f1 (int a, int n);
float f2 (int n);
int f3 (int input);

global int a;
global int n;

int main (){
	float a = 0;
	printf("a = ");
	scanf("%f", &a);
	printf("a = %f", a);
}
int f3 (int input){
	if (input == 0)
	{
		f1(a,n);
	}
	else
	{
		f2(n);
	}
}
