//using pointer to manipulate array
/*
int a[10];
int *pt;

initialize array a[] with the following rules
a[i] = i * 3 + 2;
using pointer to solve problem.
*/
#include <stdio.h>

int main () {
	int a[10];
	int *pt;
	
	pt = a;
	printf("pt address = %x \n", pt);
	printf("a[0] address = %x \n", &a[0]);
	
	*pt = 10;
	printf("a[0] = %d\n", a[0]);

	int i;
	for (i=0; i<=9; i++) {
		*pt++ = i * 10 + 2;
		printf("a[%d] = %d\n", i, a[i]);
	}
	
	return;
}



/*
epsi
int i;
i = 1
int n;
n = 0;
while(1)
{
	if (abs(pow(x,i) / i!) < epsi)
		n = i;
		print ("n = %d\n", n);
		break;
	else
		i++
}

*/
