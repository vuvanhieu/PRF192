//using pointer to compare two 
//variables
//return greater value and smaller 
//value
/*
void compare (int *pa, int *pb, 
int *pgreatter, int *psmaller) {
}
*/
#include <stdio.h>

void compare (int *pa, int *pb, int *pgreater, int *psmaller) {
	if (*pa>*pb) {
		*pgreater = *pa;
		*psmaller = *pb;
		//printf("greater = %d\n", *pgreater);
	}
	else {
		*pgreater = *pb;
		*psmaller = *pa;
		//printf("greater = %d\n", *pgreater);
	}
}

int main () {
	int a, b, greater, smaller;
	a = 10;
	b = 15;
	greater = 0;
	smaller = 0;
	printf ("a = %d, b = %d\n", a, b);
	int *pa, *pb;
	pa = &a;
	pb = &b;
	compare (pa, pb, &greater, &smaller);
	printf ("after compare greater = %d, smaller = %d\n", greater, smaller);
	return;
}



