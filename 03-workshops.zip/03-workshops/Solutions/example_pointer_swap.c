//using pointer to swap two variables
/*
void swap (int *a, int *b) {
}
*/
#include <stdio.h>

void swap (int *a, int *b) {
	int temp;
	temp = *a;
	*a = *b;
	*b = temp;
}

int main () {
	int a, b;
	a = 10;
	b = 15;	
	printf ("a = %d, b = %d\n", a, b);
	swap (&a, &b);
	printf ("after swap a = %d, b = %d\n", a, b);
	return;
}



/*
epsi
int i;
i = 1
int n;
n = 0;
while(1)
{
	if (abs(pow(x,i) / i!) < epsi)
		n = i;
		print ("n = %d\n", n);
		break;
	else
		i++
}

*/
