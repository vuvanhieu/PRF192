#include <stdio.h>

int main () {
	printf ("Enter:");
	char c = 'a';
	putchar(c);
	return;
}
