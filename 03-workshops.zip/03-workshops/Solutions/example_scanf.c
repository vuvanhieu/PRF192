#include <stdio.h>

int main (){
	float a = 0;
	printf("a = ");
	scanf("%f", &a);
	printf("a = %f", a);
}
