#include <stdio.h>

int main () {
	printf ("Enter:");
	float a, b;
	scanf("%f, %f", &a, &b);
	printf ("%f, %f\n", a, b);
	return;
}
