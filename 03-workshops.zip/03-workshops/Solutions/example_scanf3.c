#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main () {
	printf ("Enter:");
	char s[10];
	scanf("%s", s);
	printf ("%s\n", s);
	return;
}
