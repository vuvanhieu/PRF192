#include <stdio.h>

int main () {
	char name[30] = "hfdhahfd dsad fdsa";
	//scanf("%[^\n]", name);
	//printf("%s",name);
	char name2[30];
	printf("Enter string:");
	scanf("%10[^\n]", name2);
	printf("%s", name2);
	return;
}
