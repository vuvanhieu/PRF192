#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int MC = 30;

void bubble(char a[][MC+1], int size) {
	int i, j;
	char temp[MC+1];
	for (i=size-1; i>0; i--){
		for (j=0; j<i; j++){
			if (strcmp(a[j], a[j+1])>0){
				printf("before: %s, %s\n", a[j], a[j+1]);
				strcpy(temp, a[j]);
				strcpy(a[j], a[j+1]);
				strcpy(a[j+1], temp);
				printf("after: %s, %s\n", a[j], a[j+1]);
			}
		}
	}
}

int main (){
//	char* a[5] = {'\0'};
//	a[0] = "hello";
//	a[1] = "how";
//	a[2] = "are";
//	a[3] = "you";
//	a[4] = "baby";
	
	char b[5][31];
	strcpy(b[0], "hello");
	strcpy(b[1], "how");
	strcpy(b[2], "are");
	strcpy(b[3], "you");
	strcpy(b[4], "baby");
	
	int size = 5;
	bubble(b, size);
	int i = 0;
	for (i=0; i<5; i++){
		printf("%s\n", b[i]);
	}
	
	return 0;
}
