#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Book 
	{	char name [25];
		char author [20];
		int edn;
		float price;
    }; 	

int main (){
	struct Book b1;
	struct Book b2 = {"ABC","Bush",1,10.5};
	printf("author = %s\n", b2.author);
	b1.price = 10;
	strcpy(b1.name, "ABC");
	printf("Book %s has price = %f\n", b1.name, b1.price);
	char a[10];
	strcpy (a, "hello");
	return 0;
}
