#include <stdio.h>

void input(int *num, int *den) // input numerator (num) and denominator of a fraction (den)
{
	printf("enter num = ");
	scanf("%d", num);
	printf("num = %d\n", *num);
}
void display(int num, int den) // display the fraction
{
}
void simplify(int *num, int *den) // simplify the fraction
{
}

int main () {
	int num, den;
	int *pn, *pd;
	pn = &num;
	pd = &den;
	input(pn, pd);
	
	char name[30] = "hfdhahfd dsad fdsa";
	//scanf("%[^\n]", name);
	//printf("%s",name);
	char name2[30];
	printf("Enter string:");
	scanf("%10[^\n]", name2);
	printf("%s", name2);
	return;
}
