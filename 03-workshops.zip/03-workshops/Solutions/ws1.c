#include <stdio.h>
#include <math.h>

int main (){
	//Problem 1
	float a = 0, b = 0, c = 0, d = 0, x = 0;
	float S1 = 0;
	float S2 = 0;
	printf("a = ");
	scanf("%f", &a);
	//printf("\n");
	printf("b = ");
	scanf("%f", &b);
	//printf("\n");
	printf("c = ");
	scanf("%f", &c);
	//printf("\n");
	printf("x = ");
	scanf("%f", &x);
	//printf("\n");
	S1 = a * x * x + b * x + c;
	printf("S1 = %f\n", S1);
	
	if ((b*b - 4*a*c) > 0){
		S2 = sqrt(b*b - 4*a*c);
	}
	else{
		S2 = 0;
	}
	printf("S2 = %f\n", S2);
	
	printf("a = ");
	scanf("%f", &a);
	//printf("\n");
	printf("b = ");
	scanf("%f", &b);
	//printf("\n");
	printf("c = ");
	scanf("%f", &c);
	
	if (((a+b)>c) && ((a+c)>b) && ((b+c)>a)){
		float p = 0;
		p = (a + b + c) / 2;
		S1 = sqrt(p*(p-a)*(p-b)*(p-c));
		printf("p = %f\n", 2*p);
		printf("S1 = %f\n", S1);
	}
	else{
		printf("a, b, c are not side of a triangle\n");
	}
	
	//Problem 2
	printf("a = ");
	scanf("%f", &a);
	//printf("\n");
	printf("b = ");
	scanf("%f", &b);
	//printf("\n");
	printf("c = ");
	scanf("%f", &c);
	
	float min = a, max = a;
	if (b<min){
		min = b;
	}
	if (b>max){
		max = b;
	}
	if (c<min){
		min = c;
	}
	if (c>max){
		max = c;
	}
	printf("min = %f\n", min);
	printf("max = %f\n", max);
	
	if ((a <= b) && (b <= c)){
		printf("decending order: %f <= %f <= %f\n", min, b, max);
	}
	if ((a <= c) && (c <= b)){
		printf("decending order: %f <= %f <= %f\n", min, c, max);
	}
	if ((b <= a) && (a <= c)){
		printf("decending order: %f <= %f <= %f\n", min, a, max);
	}
	if ((b <= c) && (c <= a)){
		printf("decending order: %f <= %f <= %f\n", min, c, max);
	}
	if ((c <= a) && (a <= b)){
		printf("decending order: %f <= %f <= %f\n", min, a, max);
	}
	if ((c <= b) && (b <= a)){
		printf("decending order: %f <= %f <= %f\n", min, b, max);
	}
	
}
