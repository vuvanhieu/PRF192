#include <stdio.h>
#include <stdlib.h>
#include <math.h>

double myExp(double x, double epsi){
	double n;
	double condition=1;
	double S=1;
	
	n = 1;
	while(1) {
		condition *= x/n;
		S += condition;
		printf("n = %f, cond = %f, S = %f\n", n, condition, S);
		if (fabs(condition) < epsi) {
			printf("abs = %f, epsi = %f, n = %f\n", abs(condition), epsi, n);
			break;
		}
		n++;
	}
	return S;
} 

int main () {
	myExp(0.5,0.05);
	return;
}
